# CSIT314 - Road Assist
Disclaimer - The code used in this is open source and is not the property of this group.
Unless explicitly said otherwise all code does not belong to the group.

# FOLLOW FROM EACH HEADING UNTIL YOU GET TO RUNNING BEFORE TRYING TO RUN THIS APPLICATION

# Before running this document please install these requirements:

    pip install -r requirements.txt

# DATABASE:
to access the database you must have mysql downloaded\
I only know how to do this in linux, but I'm sure one of you know how to do it in windows

    sudo apt install mysql-server
  then follow the prompts\
once done do:

    sudo mysql -u root

then:

    CREATE DATABASE projectData;
    CREATE USER 'user'@'localhost' IDENTIFIED BY 'password1';
    GRANT ALL PRIVILEGES ON *.* TO 'user'@'localhost';


You will also need to install geospatial libraries

    sudo apt-get install binutils libproj-dev gdal-bin (this is for linux)

  this should work for macOS but if not follow https://tinyurl.com/mr286zhw \
  Windows users follow https://tinyurl.com/2a4kjxrz
  
# Create an admin:

    python manage.py createsuperuser 
  
  then put in login details that you will remember

# Running: 

To run this document go to the folder where the file is located.\
Linux/MacOS: cd <Directory name> (until you have reached where the file is located)\
Win        : Dir <Directory name> (until you have reached where the file is located)\
to see what directories are available use the command "$ ls" and the terminal will\
show the next available directories.

Recommend saving the folder to the home directory, so it is easy to navigate to the folder\
Once you are in the directory "roadAssist" run the command in the terminal:

    python manage.py runserver

The page will be ready to open when the last line in the terminal is:\
Quit the server with CONTROL-C.

After this proceed to your favourite web browser and input http://127.0.0.1:8000/polls/
once you're there you should be able to navigate around.

after this you should be good to go!

# Current issues

Only run this if you had an older version of the code.

If you are having issues with the user.customer.address exists, user.customer.vehicle exists etc., follow these steps:
  in mysql:

    DROP DATABASE projectData;
    USE projectData;
    GRANT ALL PRIVILEGES ON *.* TO 'user'@'localhost'

  in wherever you are editing the website code, open terminal and run these commands:
         
    find . -path "/migrations/.py" -not -name "init.py" -delete
    find . -path "/migrations/.pyc"  -delete 
  after completing above commands, run commands:
    
    python manage.py makemigrations
    python manage.py migrate 
  
  on the project code
  
# To see the gps stuff follow:

    python manage.py shell
    from world import load
    load.run()

  ctrl+d to exit\
  good to go