from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.validators import MaxValueValidator, MinValueValidator

import datetime


class Service(models.Model):
    MECHANICAL_FAILURE = (
        ("1", "Flat Batteries"),
        ("2", "Flat Tyres"),
        ("3", "Towing"),
        ("4", "Locked Out"),
        ("5", "Emergency Fuel Delivery"),
    )

    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    mobile_number = models.CharField(max_length=10)
    service_type = models.CharField(max_length=2, choices=MECHANICAL_FAILURE, default="1")
    description = models.TextField()
    ip_address = models.GenericIPAddressField(null=True)

    lat = models.DecimalField(max_digits=9, decimal_places=6, default=None)
    lon = models.DecimalField(max_digits=9, decimal_places=6, default=None)

    def __str__(self):
        return self.first_name


class Address(models.Model):
    streetno = models.CharField(max_length=10)
    streetname = models.CharField(max_length=50)
    suburb = models.CharField(max_length=20)
    state = models.CharField(max_length=20)
    zip = models.CharField(max_length=4)

    def __str__(self):
        string = self.streetno
        string += " " + self.streetname + " "
        string += self.suburb
        string += " " + self.state + " "
        string += self.zip
        return string


class Vehicle(models.Model):
    rego = models.CharField(max_length=10)
    make = models.CharField(max_length=20)
    model = models.CharField(max_length=20)
    year = models.IntegerField()
    engine = models.CharField(max_length=5)

    def __str__(self):
        string = self.rego
        string += ' '
        string += self.make
        string += ' '
        string += self.model
        string += ' '
        string += str(self.year)
        string += ' '
        string += self.engine
        return string


class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    DOB = models.DateField()
    mobile = models.IntegerField(validators=[MinValueValidator(100000000), MaxValueValidator(999999999)])
    subtype = [('Standard', 'Standard'),
               ('Premium', 'Premium')]
    subscriptiontype = models.CharField(max_length=8, choices=subtype)
    address = models.OneToOneField(Address, on_delete=models.CASCADE, default=None, null=True)
    vehicle = models.OneToOneField(Vehicle, on_delete=models.CASCADE, default=None, null=True)

    def __str__(self):
        return str(self.user.username)


class Professional(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    DOB = models.DateField()
    mobile = models.IntegerField(validators=[MinValueValidator(100000000), MaxValueValidator(999999999)])
    address = models.OneToOneField(Address, on_delete=models.CASCADE, default=None, null=True)

    def __str__(self):
        return str(self.user.username)
