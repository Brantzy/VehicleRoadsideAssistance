(function($) {
    "use strict"

    



})(jQuery);