from typing import Text
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Service, Customer, Address, Vehicle, Professional


class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=100)
    last_name = forms.CharField(max_length=100)

    class Meta:
        model = User
        fields = ['username', "first_name", "last_name", "email", "password1", "password2"]

    def __init__(self, *args, **kwargs):
        super(RegisterForm, self).__init__(*args, **kwargs)
        self.fields['username'].widget.attrs['placeholder'] = 'Username'
        self.fields['first_name'].widget.attrs['placeholder'] = 'First name'
        self.fields['last_name'].widget.attrs['placeholder'] = 'Last name'
        self.fields['email'].widget.attrs['placeholder'] = 'Email Address'
        self.fields['password1'].widget.attrs['placeholder'] = 'Password'
        self.fields['password2'].widget.attrs['placeholder'] = 'Confirm Password'


YEARS = [x for x in range(1920, 2022)]


class Customerform(forms.ModelForm):
    sub_choices = (('Standard', 'Standard '),
                   ('Premium', 'Premium '))
    subscriptiontype = forms.ChoiceField(choices=sub_choices)
    mobile = forms.CharField(label='mobile',
                             widget=forms.TextInput(attrs={'placeholder': 'Mobile Number'}))
    DOB = forms.DateField(label='DOB',
                          widget=forms.SelectDateWidget(years=YEARS), required=True)

    class Meta:
        model = Customer
        fields = ['subscriptiontype', 'mobile', 'DOB']


class Professionalform(forms.ModelForm):
    mobile = forms.CharField(label='mobile',
                             widget=forms.TextInput(attrs={'placeholder': 'Mobile Number'}))
    DOB = forms.DateField(label='DOB',
                          widget=forms.SelectDateWidget(years=YEARS), required=True, )

    class Meta:
        model = Professional
        fields = ['mobile', 'DOB']


class AddressRegisterForm(forms.ModelForm):
    streetno = forms.IntegerField(widget=forms.TextInput, required=True)
    streetname = forms.CharField(widget=forms.TextInput, required=True)
    suburb = forms.CharField(widget=forms.TextInput, required=True)
    state = forms.CharField(widget=forms.TextInput, required=True)
    zip = forms.CharField(widget=forms.TextInput, required=True)

    class Meta:
        model = Address
        fields = ["streetno", "streetname", "suburb", "state", "zip"]

    def __init__(self, *args, **kwargs):
        super(AddressRegisterForm, self).__init__(*args, **kwargs)

        self.fields['streetno'].widget.attrs['placeholder'] = 'Street Number'
        self.fields['streetname'].widget.attrs['placeholder'] = 'Street Name'
        self.fields['suburb'].widget.attrs['placeholder'] = 'Suburb'
        self.fields['state'].widget.attrs['placeholder'] = 'State'
        self.fields['zip'].widget.attrs['placeholder'] = 'Zip Code'


class VehicleRegisterForm(forms.ModelForm):
    rego = forms.CharField(widget=forms.TextInput, required=True)
    make = forms.CharField(widget=forms.TextInput, required=True)
    model = forms.CharField(widget=forms.TextInput, required=True)
    year = forms.IntegerField(widget=forms.TextInput, required=True)
    engine = forms.CharField(widget=forms.TextInput, required=True)

    class Meta:
        model = Vehicle
        fields = ["rego", "make", "model", "year", "engine"]

    def __init__(self, *args, **kwargs):
        super(VehicleRegisterForm, self).__init__(*args, **kwargs)
        self.fields['rego'].widget.attrs['placeholder'] = 'Car Registration'
        self.fields['make'].widget.attrs['placeholder'] = 'Car Make'
        self.fields['model'].widget.attrs['placeholder'] = 'Car Model'
        self.fields['year'].widget.attrs['placeholder'] = 'Year'
        self.fields['engine'].widget.attrs['placeholder'] = 'Engine type'


class ServiceForm(forms.ModelForm):
    class Meta:
        model = Service
        fields = ('first_name', 'last_name', 'mobile_number', 'service_type', 'description')


class UpdateUserForm(forms.ModelForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=100)
    last_name = forms.CharField(max_length=100)

    class Meta:
        model = User
        fields = ["first_name", "last_name", "email"]


class UpdateCustomerForm(forms.ModelForm):
    sub_choices = (('Standard', 'Standard '),
                   ('Premium', 'Premium '))
    subscriptiontype = forms.ChoiceField(choices=sub_choices)
    mobile = forms.IntegerField(label='mobile',
                                widget=forms.TextInput(attrs={'placeholder': 'Mobile Number'}))

    class Meta:
        model = Customer
        fields = ['subscriptiontype', 'mobile']


class UpdateProfessionalForm(forms.ModelForm):
    mobile = forms.IntegerField(label='mobile',
                                widget=forms.TextInput(attrs={'placeholder': 'Mobile Number'}))

    class Meta:
        model = Professional
        fields = ['mobile']
